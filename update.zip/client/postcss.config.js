export default {
  plugins: {},
};
