using Microsoft.EntityFrameworkCore;
using Blackstone_Interior;
using System.Text.Json.Serialization;
var builder = WebApplication.CreateBuilder(args);

// 1. SERVICES
builder.Services.AddControllers()
    .AddJsonOptions(options =>
    {
        options.JsonSerializerOptions.ReferenceHandler =
            System.Text.Json.Serialization.ReferenceHandler.IgnoreCycles;
    });
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Enable Response Compression for faster API responses
builder.Services.AddResponseCompression(options =>
{
    options.EnableForHttps = true;
    options.Providers.Add<Microsoft.AspNetCore.ResponseCompression.BrotliCompressionProvider>();
    options.Providers.Add<Microsoft.AspNetCore.ResponseCompression.GzipCompressionProvider>();
});

// 2. CORS Ã¢â‚¬â€  allow the Vite dev server
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowFrontend", policy =>
    {
        policy.WithOrigins("http://localhost:5173", "http://localhost:3000","http://localhost:5174")
              .AllowAnyHeader()
              .AllowAnyMethod();
    });
});

// 3. MYSQL via Pomelo EF Core
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");
var serverVersion = ServerVersion.Parse("8.0.36-mysql");
builder.Services.AddDbContext<BlackstoneinteriorDbContext>(options =>
    options.UseMySql(connectionString, serverVersion));

// 4. CONFIGURE PORT 5000

var app = builder.Build();

try
{
    using var scope = app.Services.CreateScope();
    var db = scope.ServiceProvider.GetRequiredService<BlackstoneinteriorDbContext>();
    
    // Apply pending migrations automatically on startup
    db.Database.Migrate();
    
    db.Database.CanConnect();
    Console.WriteLine("DB CONNECTION SUCCESSFUL!");
    
    // Seed sample data
    // try
    // {
    //     DataSeeder.SeedData(db);
    //     Console.WriteLine("DATA SEEDED SUCCESSFULLY!");
    // }
    // catch (Exception ex)
    // {
    //     Console.WriteLine("DATA SEEDING FAILED: " + ex.Message);
    // }
}
catch (Exception ex)
{
    Console.WriteLine("DB CONNECTION FAILED: " + ex.Message);
    if (ex.InnerException != null) Console.WriteLine("INNER EXCEPTION: " + ex.InnerException.Message);
}

// 5. PIPELINE
app.UseResponseCompression();
app.UseMiddleware<Blackstone_Interior.Middleware.GlobalExceptionMiddleware>();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseCors("AllowFrontend");
app.UseAuthorization();
app.MapControllers();

app.Run();
